// LinkedIn Feed Vanisher — Popup Script
// Handles the toggle UI and communicates with the content script.

const STORAGE_KEY = 'feedPreferences';
const LEGACY_STORAGE_KEY = 'feedVanished';

const DEFAULT_FEED_STATE = {
  blockNewsFeed: true,
  blockNotificationsFeed: false,
};

const newsToggle = document.getElementById('newsToggle');
const notificationsToggle = document.getElementById('notificationsToggle');
const statusBadge = document.getElementById('statusBadge');
const statusText = document.getElementById('statusText');

function normalizeFeedState(rawState, legacyVanished) {
  if (rawState && typeof rawState === 'object') {
    return {
      blockNewsFeed:
        typeof rawState.blockNewsFeed === 'boolean'
          ? rawState.blockNewsFeed
          : DEFAULT_FEED_STATE.blockNewsFeed,
      blockNotificationsFeed:
        typeof rawState.blockNotificationsFeed === 'boolean'
          ? rawState.blockNotificationsFeed
          : DEFAULT_FEED_STATE.blockNotificationsFeed,
    };
  }

  if (typeof legacyVanished === 'boolean') {
    return {
      blockNewsFeed: legacyVanished,
      blockNotificationsFeed: DEFAULT_FEED_STATE.blockNotificationsFeed,
    };
  }

  return { ...DEFAULT_FEED_STATE };
}

function isAnyFeedBlocked(feedState) {
  return feedState.blockNewsFeed || feedState.blockNotificationsFeed;
}

function getFeedStateFromUI() {
  return {
    blockNewsFeed: newsToggle.checked,
    blockNotificationsFeed: notificationsToggle.checked,
  };
}

/** Update the popup UI to reflect the current state. */
function updateUI(feedState) {
  newsToggle.checked = feedState.blockNewsFeed;
  notificationsToggle.checked = feedState.blockNotificationsFeed;

  if (isAnyFeedBlocked(feedState)) {
    statusBadge.className = 'status-badge vanished';
    statusText.textContent = 'Blocking one or more feeds';
  } else {
    statusBadge.className = 'status-badge visible';
    statusText.textContent = 'All feeds are visible';
  }
}

// Firefox-specific: persist state, notify content script, update background.

/** Persist state, notify the content script, and update the background. */
function applyAndSave(feedState) {
  browser.storage.local.set({
    [STORAGE_KEY]: feedState,
    [LEGACY_STORAGE_KEY]: feedState.blockNewsFeed,
  });

  // Notify the active tab's content script.
  browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
    if (tabs[0]?.id) {
      browser.tabs.sendMessage(tabs[0].id, { action: 'setFeedState', feedState });
    }
  });

  // Notify the background script to update the badge.
  browser.runtime.sendMessage({ action: 'stateChanged', feedState });

  updateUI(feedState);
}

// Initialise the popup with the persisted state.
browser.storage.local.get([STORAGE_KEY, LEGACY_STORAGE_KEY]).then((result) => {
  const feedState = normalizeFeedState(result[STORAGE_KEY], result[LEGACY_STORAGE_KEY]);
  updateUI(feedState);
});

// Handle toggle clicks.
newsToggle.addEventListener('change', () => {
  applyAndSave(getFeedStateFromUI());
});

notificationsToggle.addEventListener('change', () => {
  applyAndSave(getFeedStateFromUI());
});
